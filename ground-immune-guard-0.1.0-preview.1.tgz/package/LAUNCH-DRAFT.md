# Launch message — not approved for publication

AI agents should not need your write credentials.

GROUND IMMUNE Guard puts an authorization boundary between an agent's intent and credential-bearing execution. Start in Shadow. Move to enforcement only after deployment qualification and explicit approval.

The Technical Preview offers a small API, local evidence and a GitHub metadata example. Physical credential isolation is not yet verified for this candidate; see the security model and limitations. Request a Shadow Pilot — destination pending human approval.
