# GROUND IMMUNE Guard v0.1 — Technical Preview

**Keep write credentials away from AI agents.**

Guard evaluates an agent's operation intent before a credential-holding Broker executes it. The goal is a small authorization boundary for automation that needs to write to another system. The Agent must not own the write credential or configure its own authority.

```text
AI Agent / Automation → operation intent → Guard
                                          ├─ DENIED → STOP
                                          ├─ UNRESOLVED → STOP
                                          └─ ADMITTED → Broker → Protected System
                                                       credential holder
```

This diagram describes explicitly enabled enforcement. **SHADOW is the default**: it observes the customer's existing operation, does not block it, and never calls the Guard Broker. DENIED means outside the configured authority; UNRESOLVED means the required basis for a safe decision is missing. Neither executes through the enforcement path.

## Install and first operation

Requires externally supplied Node.js 22 or later and npm. This is an unpublished candidate; the following local tarball command works after receiving the approved bundle. It is not a registry availability claim.

```sh
npm install --offline --ignore-scripts ./ground-immune-guard-0.1.0-preview.1.tgz
./node_modules/.bin/guard init ./guard-local
./node_modules/.bin/guard doctor ./guard-local
./node_modules/.bin/guard protect ./guard-local allowed
./node_modules/.bin/guard protect ./guard-local denied
./node_modules/.bin/guard explain ./guard-local
./node_modules/.bin/guard verify ./guard-local
```

These commands use local, non-production authority and a simulated Broker; no credential or network transport is created. Follow [Quickstart](QUICKSTART.md) for JavaScript/TypeScript, a single scope and simulated execution. Follow [GitHub](GITHUB.md) for metadata mapping and the separate deployment qualification required before enforcement.

## Preview boundaries

The package includes intent evaluation, scope binding, local evidence, a local CLI and GitHub mapping. It does not include a dedicated Broker host, credential provisioning or a real GitHub write transport. Physical credential isolation has **not yet been verified** for this release. In-process binding is not process or OS isolation. A trusted host must own policy, providers, evidence and execution.

Read [Security Model](SECURITY-MODEL.md), [Threat Model](THREAT-MODEL.md), [Limitations](LIMITATIONS.md) and [Data Handling](PRIVACY.md). [API](API.md) is a preview freeze candidate, not a promise of permanent compatibility.

Security contact: **UNASSIGNED — publication blocked**; see [reporting policy](SECURITY.md). Product license/terms and distribution approval are pending; see [license state](LICENSE-STATE.md). Do not redistribute this unpublished candidate.

**Request a Shadow Pilot** — contact destination pending human approval. Start with one narrowly scoped operation and measure setup friction, decisions and latency before considering enforcement.
