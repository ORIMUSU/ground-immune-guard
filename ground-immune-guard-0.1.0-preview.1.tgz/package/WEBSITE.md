# Keep write credentials away from AI agents.

GROUND IMMUNE Guard evaluates agent operations before a credential-holding Broker executes them.

## The problem

Automation often needs to change files or update a repository. Handing the Agent a reusable write credential also gives it a route around application checks. Put intent evaluation and credential-bearing execution on separately controlled sides of the boundary.

## The architecture

Agent → operation intent → Guard → ADMITTED → Broker → protected system.
DENIED and UNRESOLVED stop before Broker in enforcement mode. The Agent cannot choose its own authority or replace the trusted executor. Physical credential isolation requires a separately qualified deployment; it is not established by installing a library.

## Three clear decisions

ADMITTED: the reviewed operation matches the configured authority and evidence. DENIED: the request conflicts with scope or policy. UNRESOLVED: required evidence or system state is insufficient. Missing information is not treated as permission.

## Start with GitHub

Map numeric repository identity, branch, paths and revisions into a single scope. Begin with non-blocking Shadow observations. The preview ships a metadata adapter and local example, not a credential-provisioning service. A real Broker needs separate host qualification and remote branch controls.

## Explain each operation

See the operation, actor, scope, decision, reason and execution result. Local evidence can be checked and replayed against recorded trusted inputs without copying file bodies into the report. Hash chains do not make a compromised host trustworthy.

## Shadow first

Observe decisions alongside actual outcomes before changing the write path. Shadow does not block or invoke the Guard Broker. Enforcement requires explicit configuration, qualified infrastructure and a human decision; there is no automatic promotion.

## Technical Preview

Local tests and controlled GitHub pilots provide bounded evidence. Real physical credential isolation is not yet verified. This is not a production certification, universal attack detector or a guarantee against Broker-host compromise. See LIMITATIONS.md and SECURITY-MODEL.md.

## Try one operation

Follow QUICKSTART.md with a locally supplied preview tarball. The demo uses a local simulated Broker and needs no credential. Measure first-operation completion, setup failures, confusing assumptions, decision latency and operational friction; download counts alone are not success.

## Request a Shadow Pilot

For teams using AI Agents for GitHub writes or internal automation: begin with one narrowly defined operation, then consider up to three after explicit review. Provide a description of your environment, not credentials. Contact destination: **UNASSIGNED — publication blocked**. Security reporting contact is separately pending in SECURITY.md. No intake form or tracking service is active.
